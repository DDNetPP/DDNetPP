#ifndef BASE_CONFUSABLES_H
#define BASE_CONFUSABLES_H

#include "detect.h"

#ifdef __cplusplus
extern "C" {
#endif

int str_utf8_is_confusable(int smaller, int bigger);

#ifdef __cplusplus
}
#endif

#endif
