#ifndef SHARED_ARRAY_CPP
#define SHARED_ARRAY_CPP
#include "array.h"

template <class T, bool S>
CArray<T, S>::CArray()
{
	m_pFirst = 0;
	m_pLast = 0;
	m_Size = 0;
	m_pSelectedItem = 0;
	m_SelectedIndex = 0;
	m_LastIndex = 0;
}

template <class T, bool S>
CArray<T, S>::CArray(CArray& Other)
{
	m_pFirst = 0;
	m_pLast = 0;
	m_Size = 0;
	ClearSelection();
	m_LastIndex = 0;

	CArrayItem *pItem = Other.m_pFirst;
	while (pItem)
	{
		CArrayItem *pNew = InsertInternal(pItem->m_Value, m_pLast, true);
		pNew->m_Index = pItem->m_Index;
		pItem = pItem->m_pNext;
	}
}

template <class T, bool S>
CArray<T, S>::~CArray()
{
	CArrayItem *pItem = m_pFirst;
	for (long long i = 0; i < m_Size && pItem; i++)
	{
		CArrayItem *pDel = pItem;
		pItem = pItem->m_pNext;
		delete pDel;
	}
}

template <class T, bool S>
long long CArray<T, S>::Insert(const T &Value, long long BeforeIndex)
{
	if (BeforeIndex > -1)
	{
		CArrayItem *pItem = m_pFirst;
		long long i = 0;
		for (; i < BeforeIndex && pItem; i++)
		{
			pItem = pItem->m_pNext;
		}
		if (i == BeforeIndex && pItem)
		{
			InsertInternal(Value, pItem);
			int Ret = m_Size;
			if (S)
				Ret = m_LastIndex;
			return Ret;
		}
	}
	InsertInternal(Value, m_pLast, true);
	int Ret = m_Size;
	if (S)
		Ret = m_LastIndex;
	return Ret;
}

template <class T, bool S>
void CArray<T, S>::Push(const T &Value)
{
	Insert(Value);
}

template <class T, bool S>
void CArray<T, S>::DeleteInternal(CArrayItem *pItem)
{
	if (!pItem)
		return;
	CArrayItem *pPrev = 0;
	CArrayItem *pNext = 0;
	pPrev = pItem->m_pPrev;
	pNext = pItem->m_pNext;
	if (pPrev)
	{
		pPrev->m_pNext = pNext;
	}
	if (pNext)
	{
		pNext->m_pPrev = pPrev;
	}
	if (pItem == m_pFirst)
		m_pFirst = pNext;
	if (pItem == m_pLast)
		m_pLast = pPrev;
	delete pItem;

	m_Size--;
	ClearSelection();
}

template <class T, bool S>
void CArray<T, S>::DeleteByValue(const T &Value)
{
	CArrayItem *pItem = m_pFirst;
	while (pItem)
	{
		CArrayItem *pNext = pItem->m_pNext;
		if (pItem->m_Value == Value)
		{
			DeleteInternal(pItem);
		}
		pItem = pNext;
	}
}

template <class T, bool S>
void CArray<T, S>::DeleteByIndex(long long Index)
{
	CArrayItem *pItem = m_pFirst;
	for (long long i = 0; pItem; i++)
	{
		if (S)
		{
			if (pItem->m_Index == Index)
			{
				DeleteInternal(pItem);
				break;
			}
		}
		else if (i == Index)
		{
			DeleteInternal(pItem);
			break;
		}
		pItem = pItem->m_pNext;
	}
}

template <class T, bool S>
void CArray<T, S>::DeleteBySelection()
{
	if (m_pSelectedItem)
	{
		DeleteInternal(m_pSelectedItem);
	}
}

template <class T, bool S>
typename CArray<T, S>::CArrayItem *CArray<T, S>::InsertInternal(const T &Value, CArrayItem *pItem, bool After)
{
	CArrayItem *pPrev = 0;
	CArrayItem *pNext = 0;
	CArrayItem *pNew = new CArrayItem();

	if (S)
	{
		pNew->m_Index = m_LastIndex++;
	}

	if (pItem)
	{
		if (After)
		{
			pPrev = pItem;
			pNext = pItem->m_pNext;
		}
		else
		{
			pPrev = pItem->m_pPrev;
			pNext = pItem;
		}
	}

	pNew->m_pNext = pNext;
	pNew->m_pPrev = pPrev;

	if (pPrev)
		pPrev->m_pNext = pNew;
	else
		m_pFirst = pNew;

	if (pNext)
		pNext->m_pPrev = pNew;
	else
		m_pLast = pNew;

	pNew->m_Value = Value;

	m_Size++;

	ClearSelection();
	return pNew;
}

template <class T, bool S>
void CArray<T, S>::Clear()
{
	while (m_pFirst)
		DeleteInternal(m_pFirst);
}

template <class T, bool S>
void CArray<T, S>::ClearSelection()
{
	m_pSelectedItem = m_pFirst;
	m_SelectedIndex = 0;
}

template <class T, bool S>
void CArray<T, S>::SwapInternal(CArrayItem *pA, CArrayItem *pB)
{
	if (pA->m_pPrev && pA->m_pPrev != pB)
		pA->m_pPrev->m_pNext = pB;
	if (pA->m_pNext && pA->m_pNext != pB)
		pA->m_pNext->m_pPrev = pB;

	if (pB->m_pPrev && pB->m_pPrev != pA)
		pB->m_pPrev->m_pNext = pA;
	if (pB->m_pNext && pB->m_pNext != pA)
		pB->m_pNext->m_pPrev = pA;


	if (pA == m_pFirst)
		m_pFirst = pB;
	else if (pB == m_pFirst)
		m_pFirst = pA;

	if (pA == m_pLast)
		m_pLast = pB;
	else if (pB == m_pLast)
		m_pLast = pA;

	if (m_pSelectedItem == pA)
		m_pSelectedItem = pB;
	else if (m_pSelectedItem == pB)
		m_pSelectedItem = pA;
	//ClearSelection(); //invalid?

	CArrayItem *pAPrev = pA->m_pPrev;
	CArrayItem *pANext = pA->m_pNext;

	if (pB->m_pPrev == pA)
		pA->m_pPrev = pB;
	else
		pA->m_pPrev = pB->m_pPrev;

	if (pB->m_pNext == pA)
		pA->m_pNext = pB;
	else
		pA->m_pNext = pB->m_pNext;

	if (pAPrev == pB)
		pB->m_pPrev = pA;
	else
		pB->m_pPrev = pAPrev;

	if (pANext == pB)
		pB->m_pNext = pA;
	else
		pB->m_pNext = pANext;
}

template <class T, bool S>
void CArray<T, S>::Sort()
{
	if (!m_pSortFunction)
		return;

	CArrayItem *pSelected = m_pFirst;
	int Swapped = 1;
	while (Swapped)
	{
		Swapped = 0;
		pSelected = m_pFirst;
		while (1)
		{
			if (!pSelected)
				break;
			CArrayItem *pCheckItem = pSelected->m_pNext;
			if (!pCheckItem)
				break;
			if (m_pSortFunction(pCheckItem->m_Value, pSelected->m_Value))
			{
				SwapInternal(pCheckItem, pSelected);
				Swapped++;
			}
			else
				pSelected = pSelected->m_pNext;
		}
		dbg_msg("array", "%d", Swapped);
	}
}

//next
template <class T, bool S>
long long CArray<T, S>::operator> (long long i)
{
	int Index = -1;
	if (!m_pSelectedItem)
	{
		m_pSelectedItem = m_pFirst;
		m_SelectedIndex = 0;
	}
	while (i > 0 && m_pSelectedItem)
	{
		m_pSelectedItem = m_pSelectedItem->m_pNext;
		m_SelectedIndex++;
		i--;
	}
	if (S)
	{
		if (i == 0 && m_pSelectedItem)
			Index = m_pSelectedItem->m_Index;
	}
	else
	{
		if (i == 0 && m_pSelectedItem)
			Index = m_SelectedIndex;
	}
	return Index;
}

//last
template <class T, bool S>
long long CArray<T, S>::operator >> (long long i)
{
	int Index = -1;
	m_pSelectedItem = m_pLast;
	m_SelectedIndex = m_Size;
	if (m_pSelectedItem)
	{
		if (S)
			Index = m_pSelectedItem->m_Index;
		else
			Index = m_SelectedIndex;
	}
	return Index;
}

//prev
template <class T, bool S>
long long CArray<T, S>::operator< (long long i)
{
	int Index = -1;
	if (!m_pSelectedItem)
	{
		m_pSelectedItem = m_pLast;
		m_SelectedIndex = m_Size;
	}
	while (i > 0 && m_pSelectedItem)
	{
		m_pSelectedItem = m_pSelectedItem->m_Prev;
		m_SelectedIndex--;
		i--;
	}
	if (S)
	{
		if (i == 0 && m_pSelectedItem)
			Index = m_pSelectedItem->m_Index;
	}
	else
	{
		if (i == 0 && m_pSelectedItem)
			Index = m_SelectedIndex;
	}
	return Index;
}

//first
template <class T, bool S>
long long CArray<T, S>::operator<< (long long i)
{
	int Index = -1;
	m_pSelectedItem = m_pFirst;
	m_SelectedIndex = 0;
	if (m_pSelectedItem)
	{
		if (S)
			Index = m_pSelectedItem->m_Index;
		else
			Index = m_SelectedIndex;
	}
	return Index;
}

template <class T, bool S>
typename CArray<T, S>::CArrayItem *CArray<T, S>::GetInternal(long long i)
{
	if (S)
	{
		m_pSelectedItem = m_pFirst;
		m_SelectedIndex = 0;
		while (m_pSelectedItem)
		{
			if (m_pSelectedItem->m_Index == i)
			{
				return m_pSelectedItem;
			}
			m_pSelectedItem = m_pSelectedItem->m_pNext;
			m_SelectedIndex++;
		}
	}
	else //use generic index
	{
		if (m_pSelectedItem == 0)
			m_pSelectedItem = m_pFirst;
		if (i == 0)
		{
			m_SelectedIndex = i;
			m_pSelectedItem = m_pFirst;
			return m_pSelectedItem;
		}
		else if (i == m_Size - 1)
		{
			m_SelectedIndex = i;
			m_pSelectedItem = m_pLast;
			return m_pSelectedItem;
		}
		while (m_Size > i && i >= 0 && m_pSelectedItem)
		{
			if (m_SelectedIndex > i)
			{
				m_pSelectedItem = m_pSelectedItem->m_pPrev;
				m_SelectedIndex--;
			}
			else if (m_SelectedIndex < i)
			{
				m_pSelectedItem = m_pSelectedItem->m_pNext;
				m_SelectedIndex++;
			}
			if (m_SelectedIndex == i)
			{
				return m_pSelectedItem;
			}
		}
	}
	return 0;
}

template <class T, bool S>
T CArray<T, S>::operator[] (long long i)
{
	CArrayItem *pItem = GetInternal(i);
	if (pItem)
		return pItem->m_Value;
	return T();
}

template <class T, bool S>
T CArray<T, S>::Pop()
{
	if (!m_pFirst)
	{
		return T();
	}
	T Value = m_pFirst->m_Value;
	DeleteInternal(m_pFirst);
	return Value;
}

#endif
