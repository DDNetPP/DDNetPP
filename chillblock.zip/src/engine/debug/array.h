#ifndef SHARED_ARRAY_H
#define SHARED_ARRAY_H
#include <base/system.h>

template <class T, bool S = false>
class CArray
{
	struct CArrayItem
	{
		T m_Value;
		unsigned long long m_Index;
		CArrayItem *m_pNext;
		CArrayItem *m_pPrev;
	};



	CArrayItem *m_pFirst;
	CArrayItem *m_pLast;

	CArrayItem *m_pSelectedItem; //for fast inorder iteration
	long long m_SelectedIndex;

	volatile long long m_Size;

	volatile long long m_LastIndex; //used for static index -> S

									//remove After and use a pItem == 0 as a replacement
	CArrayItem *InsertInternal(const T &Value, CArrayItem *pItem, bool After = false);
	void DeleteInternal(CArrayItem *pItem);
	void SwapInternal(CArrayItem *pA, CArrayItem *pB);
	CArrayItem *GetInternal(long long i);

	void ClearSelection();


public:
	CArray();
	CArray(CArray& Other);
	~CArray();

	long long Insert(const T &Value, long long BeforeIndex = -1);
	void Push(const T &Value);
	void DeleteByValue(const T &Value);
	void DeleteByIndex(long long Index);
	void DeleteBySelection();
	void Clear();

	//void Swap();
	void Sort();
	bool(*m_pSortFunction)(T Right, T Left);

	T Pop();

	T operator[] (long long i);

	long long operator> (long long i);
	long long operator >> (long long i);
	long long operator< (long long i);
	long long operator<< (long long i);

	inline long long Size() { return m_Size; }
	inline long long LastIndex() { return m_LastIndex; }
};

#include "array.cpp" //include the code
#endif

