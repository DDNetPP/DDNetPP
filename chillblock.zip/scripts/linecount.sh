#!/bin/sh
wc `find . -iname *.cpp` `find . -iname *.h` `find . -iname *.c`
